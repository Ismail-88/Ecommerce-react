import { Edit2, Eye, Trash2 } from "lucide-react";
import { useNavigate } from "react-router-dom";

const ProductCard = ({ product, onDelete }) => {

    const navigate = useNavigate()
  const getImageUrl = (imagePath) => {
    if (!imagePath) return "https://via.placeholder.com/300x300?text=No+Image";
    if (imagePath.startsWith("http")) return imagePath;
    return `http://localhost:5000${imagePath}`;
  };

  const firstImage = Array.isArray(product.images)
    ? product.images[0]
    : product.images;
  const imageUrl = getImageUrl(firstImage);


  return (
    <div className="group bg-white rounded-2xl shadow-lg hover:shadow-2xl transition-all duration-300 overflow-hidden">
      {/* Image */}
      <div className="relative h-56 overflow-hidden bg-gray-100">
        <img
          src={imageUrl}
          alt={product.title}
          className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
           onError={(e) => {
            e.target.src = "https://via.placeholder.com/300x300?text=No+Image";
          }}
        />

        {/* Badges */}
        <div className="absolute top-3 left-3 flex flex-col gap-2">
          {product.discount > 0 && (
            <span className="bg-red-500 text-white px-3 py-1 rounded-lg text-sm font-bold shadow-lg">
              -{product.discount}%
            </span>
          )}
          {(product.stock || 0) < 10 && (
            <span className="bg-yellow-500 text-white px-3 py-1 rounded-lg text-xs font-bold shadow-lg">
              Low Stock
            </span>
          )}
        </div>

        {/* Hover Actions */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-all duration-300 flex items-center justify-center gap-3">
          <button
            onClick={() => navigate(`/product/${product._id}`)}
            className="bg-white text-gray-800 p-3 rounded-xl hover:scale-110 transition-transform shadow-xl"
            title="View"
          >
            <Eye size={20} />
          </button>
          <button
            onClick={() => navigate(`/admin/products/edit/${product._id}`)}
            className="bg-blue-500 text-white p-3 rounded-xl hover:scale-110 transition-transform shadow-xl"
            title="Edit"
          >
            <Edit2 size={20} />
          </button>
          <button
            onClick={() => {
              onDelete(product)
            }}
            className="bg-red-500 text-white p-3 rounded-xl hover:scale-110 transition-transform shadow-xl"
            title="Delete"
          >
            <Trash2 size={20} />
          </button>
        </div>
      </div>

      {/* Content */}
      <div className="p-5 space-y-4">
        <div>
          <span className="inline-block text-xs font-bold text-red-600 bg-red-50 px-3 py-1 rounded-full mb-2">
            {product.category?.name || "Uncategorized"}
          </span>
          <h3 className="text-lg font-bold text-gray-900 line-clamp-2 mb-2">
            {product.title}
          </h3>
          <p className="text-sm text-gray-500 line-clamp-2">
            {product.description}
          </p>
        </div>

        <div className="flex items-end justify-between pt-4 border-t border-gray-100">
          <div>
            <p className="text-sm text-gray-500 mb-1">Price</p>
            <div className="flex items-baseline gap-2">
              <span className="text-2xl font-bold text-red-600">
                ${product.price}
              </span>
              {product.discount > 0 && (
                <span className="text-sm text-gray-400 line-through">
                  ${(product.price / (1 - product.discount / 100)).toFixed(2)}
                </span>
              )}
            </div>
          </div>
          <div className="text-right">
            <p className="text-sm text-gray-500 mb-1">Stock</p>
            <p
              className={`text-xl font-bold ${
                (product.stock || 0) < 10 ? "text-red-500" : "text-green-500"
              }`}
            >
              {product.stock || 0}
            </p>
          </div>
        </div>

        <div className="flex gap-2 pt-2">
          <button
            onClick={() => navigate(`/admin/products/edit/${product._id}`)}
            className="flex-1 bg-gradient-to-r from-blue-500 to-blue-600 text-white py-2.5 rounded-xl font-bold hover:scale-105 transition-all flex items-center justify-center gap-2 shadow-lg"
          >
            <Edit2 size={16} /> Edit
          </button>
          <button
            onClick={() => {onDelete(product)
            }}
            className="bg-gradient-to-r from-red-500 to-red-600 text-white px-4 py-2.5 rounded-xl font-bold hover:scale-105 transition-all shadow-lg"
          >
            <Trash2 size={16} />
          </button>
        </div>
      </div>
    </div>
  );
};

export default ProductCard;
