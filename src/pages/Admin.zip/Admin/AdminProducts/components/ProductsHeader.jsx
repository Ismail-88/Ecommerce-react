import { Package, Plus } from 'lucide-react'
import React from 'react'
import { useNavigate } from 'react-router-dom'

const ProductsHeader = ({productsCount}) => {

    const navigate = useNavigate();
  return (
     <div className="relative overflow-hidden bg-gradient-to-br from-red-600 via-red-500 to-pink-600 rounded-3xl shadow-2xl">
          <div className="absolute inset-0 bg-black opacity-5"></div>
          <div className="absolute -top-24 -right-24 w-96 h-96 bg-white opacity-10 rounded-full blur-3xl"></div>
          <div className="absolute -bottom-24 -left-24 w-96 h-96 bg-pink-300 opacity-10 rounded-full blur-3xl"></div>

          <div className="relative p-8 md:p-12">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
              <div className="space-y-3">
                <div className="flex items-center gap-3">
                  <div className="bg-white/20 backdrop-blur-sm p-3 rounded-2xl">
                    <Package className="text-white" size={32} />
                  </div>
                  <h1 className="text-3xl md:text-4xl font-bold text-white">
                    Product Management
                  </h1>
                </div>
                <p className="text-red-100 text-lg">
                  {productsCount} {productsCount === 1 ? "product" : "products"} in
                  your catalog
                </p>
              </div>
              <button
                onClick={() => navigate("/admin/products/add")}
                className="group relative bg-white text-red-600 px-8 py-4 rounded-2xl font-bold hover:scale-105 transition-all duration-300 flex items-center gap-3 shadow-xl hover:shadow-2xl"
              >
                <Plus
                  size={24}
                  className="group-hover:rotate-90 transition-transform duration-300"
                />
                <span>Add Product</span>
              </button>
            </div>
          </div>
        </div>
  )
}

export default ProductsHeader

