import { AlertCircle, Box, DollarSign, Tag } from 'lucide-react';
import React from 'react'

const ProductsStats = ({products, categories}) => {

     const lowStockCount = products.filter((p) => (p.stock || 0) < 10).length;
  const avgPrice =
    products.length > 0
      ? (
          products.reduce((sum, p) => sum + p.price, 0) / products.length
        ).toFixed(2)
      : "0.00";

      const stats = [
        
            {
              label: "Total Products",
              value: products.length,
              icon: Box,
              color: "blue",
              bg: "from-blue-500 to-blue-600",
            },
            {
              label: "Average Price",
              value: `$${avgPrice}`,
              icon: DollarSign,
              color: "green",
              bg: "from-green-500 to-emerald-600",
            },
            {
              label: "Low Stock Alert",
              value: lowStockCount,
              icon: AlertCircle,
              color: "yellow",
              bg: "from-yellow-500 to-orange-500",
            },
            {
              label: "Categories",
              value: categories.length,
              icon: Tag,
              color: "purple",
              bg: "from-purple-500 to-pink-600",
            },
      ]

  return (
    <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6">
          
          {stats.map((stat, index) => (
            <div
              key={index}
              className="group relative bg-white rounded-2xl shadow-lg hover:shadow-2xl transition-all duration-300 overflow-hidden"
            >
              <div
                className={`absolute inset-0 bg-gradient-to-br ${stat.bg} opacity-0 group-hover:opacity-100 transition-opacity duration-300`}
              ></div>
              <div className="relative p-6">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <p className="text-sm font-medium text-gray-600 group-hover:text-white transition-colors">
                      {stat.label}
                    </p>
                    <p className="text-3xl font-bold text-gray-900 group-hover:text-white transition-colors mt-2">
                      {stat.value}
                    </p>
                  </div>
                  <div
                    className={`bg-${stat.color}-100 group-hover:bg-white/20 p-3 rounded-xl transition-all`}
                  >
                    <stat.icon
                      className={`text-${stat.color}-600 group-hover:text-white transition-colors`}
                      size={24}
                    />
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
  )
}

export default ProductsStats
