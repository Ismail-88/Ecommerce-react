import { Trash2 } from 'lucide-react'
import React from 'react'

const DeleteProductModal = ({product, onConfirm, onCancel}) => {
  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4 animate-in fade-in duration-200">
          <div className="bg-white rounded-3xl p-8 max-w-md w-full shadow-2xl animate-in zoom-in duration-200">
            <div className="text-center">
              <div className="bg-red-100 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-6">
                <Trash2 className="text-red-500" size={40} />
              </div>
              <h3 className="text-2xl font-bold text-gray-900 mb-3">
                Delete Product?
              </h3>
              <p className="text-gray-600 mb-2">
                Are you sure you want to delete
              </p>
              <p className="font-bold text-gray-900 mb-6">
                "{product?.title}"?
              </p>
              <p className="text-sm text-red-600 mb-8">
                This action cannot be undone.
              </p>

              <div className="flex gap-3">
                <button
                   onClick={onCancel}
                  className="flex-1 px-6 py-3.5 bg-gray-100 text-gray-700 rounded-xl font-bold hover:bg-gray-200 transition-all"
                >
                  Cancel
                </button>
                <button
                  onClick={onConfirm}
                  className="flex-1 px-6 py-3.5 bg-gradient-to-r from-red-500 to-red-600 text-white rounded-xl font-bold hover:scale-105 transition-all shadow-lg"
                >
                  Delete
                </button>
              </div>
            </div>
          </div>
        </div>
  )
}

export default DeleteProductModal
