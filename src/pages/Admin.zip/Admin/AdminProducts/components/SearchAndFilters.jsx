import { ChevronLeft, Filter, Grid3x3, List, Search } from 'lucide-react'
import React from 'react'

const SearchAndFilters = ({
   searchQuery,
   setSearchQuery,
   setShowFilters,
   viewMode,
   setViewMode,
   showFilters,
   selectedCategory,
   setSelectedCategory,
   categories,
   sortBy,
   setSortBy,
   currentProductsCount,
   filteredProductsCount

}) => {
  return (
    <div className="bg-white rounded-2xl shadow-xl p-6 space-y-4">
          <div className="flex flex-col lg:flex-row gap-4">
            {/* Search */}
            <div className="flex-1 relative group">
              <Search
                className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400 group-focus-within:text-red-500 transition-colors"
                size={20}
              />
              <input
                type="text"
                placeholder="Search products by name or description..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-12 pr-4 py-3.5 border-2 border-gray-200 rounded-xl focus:ring-2 focus:ring-red-500 focus:border-red-500 transition-all outline-none"
              />
            </div>

            {/* View Toggle */}
            <div className="flex gap-2 bg-gray-100 p-1.5 rounded-xl">
              <button
                onClick={() => setViewMode("grid")}
                className={`p-3 rounded-lg transition-all ${
                  viewMode === "grid"
                    ? "bg-white text-red-500 shadow-md"
                    : "text-gray-500 hover:text-gray-700"
                }`}
              >
                <Grid3x3 size={20} />
              </button>
              <button
                onClick={() => setViewMode("list")}
                className={`p-3 rounded-lg transition-all ${
                  viewMode === "list"
                    ? "bg-white text-red-500 shadow-md"
                    : "text-gray-500 hover:text-gray-700"
                }`}
              >
                <List size={20} />
              </button>
            </div>

            {/* Filter Toggle */}
            <button
              onClick={() => setShowFilters(!showFilters)}
              className="lg:hidden flex items-center gap-2 px-6 py-3.5 bg-gray-900 text-white rounded-xl font-semibold hover:bg-gray-800 transition-all"
            >
              <Filter size={20} />
              Filters
            </button>
          </div>

          {/* Filters */}
          <div
            className={`${
              showFilters ? "block" : "hidden"
            } lg:block grid grid-cols-1 md:grid-cols-3 gap-4 pt-4 border-t border-gray-200`}
          >
            {/* Category */}
            <div className="space-y-2">
              <label className="block text-sm font-bold text-gray-700">
                Category
              </label>
              <div className="relative">
                <select
                  value={selectedCategory}
                  onChange={(e) => setSelectedCategory(e.target.value)}
                  className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:ring-2 focus:ring-red-500 focus:border-red-500 outline-none appearance-none bg-white cursor-pointer transition-all"
                >
                  <option value="all">All Categories</option>
                  {categories.map((cat) => (
                    <option key={cat._id} value={cat.name}>
                      {cat.name}
                    </option>
                  ))}
                </select>
                <ChevronLeft
                  className="absolute right-4 top-1/2 transform -translate-y-1/2 rotate-[-90deg] text-gray-400 pointer-events-none"
                  size={20}
                />
              </div>
            </div>

            {/* Sort */}
            <div className="space-y-2">
              <label className="block text-sm font-bold text-gray-700">
                Sort By
              </label>
              <div className="relative">
                <select
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value)}
                  className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:ring-2 focus:ring-red-500 focus:border-red-500 outline-none appearance-none bg-white cursor-pointer transition-all"
                >
                  <option value="newest">Newest First</option>
                  <option value="oldest">Oldest First</option>
                  <option value="price-low">Price: Low to High</option>
                  <option value="price-high">Price: High to Low</option>
                  <option value="name-az">Name: A-Z</option>
                  <option value="name-za">Name: Z-A</option>
                  <option value="stock-low">Stock: Low to High</option>
                  <option value="stock-high">Stock: High to Low</option>
                </select>
                <ChevronLeft
                  className="absolute right-4 top-1/2 transform -translate-y-1/2 rotate-[-90deg] text-gray-400 pointer-events-none"
                  size={20}
                />
              </div>
            </div>

            {/* Results */}
            <div className="space-y-2">
              <label className="block text-sm font-bold text-gray-700">
                Results
              </label>
              <div className="bg-gradient-to-r from-red-50 to-pink-50 px-4 py-3 rounded-xl border-2 border-red-200">
                <p className="text-sm font-semibold text-gray-700">
                  Showing{" "}
                  <span className="text-red-600">{currentProductsCount}</span>{" "}
                  of{" "}
                  <span className="text-red-600">
                    {filteredProductsCount.length}
                  </span>
                </p>
              </div>
            </div>
          </div>
        </div>
  )
}

export default SearchAndFilters
