import { Box, Plus } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const EmptyProductsState = ({searchQuery, selectedCategory}) => {
    const navigate = useNavigate();
  return (
    <div className="bg-white rounded-3xl shadow-xl p-16 text-center">
      <div className="bg-gray-100 w-24 h-24 rounded-full flex items-center justify-center mx-auto mb-6">
        <Box className="text-gray-400" size={48} />
      </div>
      <h3 className="text-2xl font-bold text-gray-800 mb-3">
        No Products Found
      </h3>
      <p className="text-gray-500 mb-8 max-w-md mx-auto">
        {searchQuery || selectedCategory !== "all"
          ? "Try adjusting your filters or search query to find what you're looking for"
          : "Start building your catalog by adding your first product"}
      </p>
      <button
        onClick={() => navigate("/admin/products/add")}
        className="bg-gradient-to-r from-red-500 to-pink-600 text-white px-8 py-4 rounded-xl font-bold hover:scale-105 transition-all inline-flex items-center gap-3 shadow-xl"
      >
        <Plus size={20} /> Add Your First Product
      </button>
    </div>
  );
}

export default EmptyProductsState

