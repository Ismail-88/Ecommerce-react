import React from 'react'
import { useNavigate } from 'react-router-dom'

const TopProductsGrids = ({topProducts}) => {
    const navigate = useNavigate()
  return (
    <div className="bg-white rounded-2xl shadow-lg p-6">
          <div className="flex justify-between items-center mb-6">
            <div>
              <h2 className="text-xl font-bold text-gray-800">Top Products</h2>
              <p className="text-sm text-gray-500">Best selling products</p>
            </div>
            <button
              onClick={() => navigate('/admin/products')}
              className="text-sm text-red-500 hover:text-red-600 font-semibold"
            >
              View All →
            </button>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-4">
            {topProducts.map((product, index) => (
              <div
                key={index}
                onClick={() => navigate(`/product/${product._id}`)}
                className="border border-gray-200 rounded-xl overflow-hidden hover:shadow-lg transition cursor-pointer group"
              >
                <div className="relative overflow-hidden">
                  <img
                    src={
                      Array.isArray(product.images)
                        ? product.images[0]
                        : product.images
                    }
                    alt={product.title}
                    className="w-full h-32 object-cover group-hover:scale-110 transition-transform duration-300"
                  />
                  {product.discount > 0 && (
                    <div className="absolute top-2 left-2 bg-red-500 text-white px-2 py-1 rounded-md text-xs font-bold">
                      -{product.discount}%
                    </div>
                  )}
                </div>
                <div className="p-3">
                  <h3 className="font-semibold text-sm text-gray-800 line-clamp-2 mb-1">
                    {product.title}
                  </h3>
                  <div className="flex items-center justify-between">
                    <span className="text-red-500 font-bold text-sm">${product.price}</span>
                    <span className="text-xs text-gray-500">
                      Stock: {product.stock || 0}
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
  )
}

export default TopProductsGrids
