import React from 'react'

const DashboardHeader = () => {
  return (
   
       <div className="bg-gradient-to-r from-red-500 via-pink-500 to-red-600 rounded-2xl p-6 md:p-8 text-white shadow-xl">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
            <div>
              <h1 className="text-2xl md:text-3xl font-bold mb-2">
                Welcome back, Admin! 👋
              </h1>
              <p className="text-red-100">
                Here's what's happening with your store today
              </p>
            </div>
            <div className="bg-white/20 backdrop-blur-lg rounded-xl p-4 text-center">
              <p className="text-sm text-red-100">Today's Date</p>
              <p className="text-lg md:text-xl font-bold">
                {new Date().toLocaleDateString('en-US', { 
                  month: 'short', 
                  day: 'numeric',
                  year: 'numeric'
                })}
              </p>
            </div>
          </div>
        </div>
   
  )
}

export default DashboardHeader
