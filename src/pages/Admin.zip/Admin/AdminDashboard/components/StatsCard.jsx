
import { FaArrowDown, FaArrowUp } from "react-icons/fa";
import { useNavigate } from "react-router-dom";

const StatsCard = ({ card }) => {
  const navigate = useNavigate();
  return (
    <div
      onClick={() => navigate(card.link)}
      className="bg-white rounded-2xl shadow-lg hover:shadow-2xl transition-all duration-300 overflow-hidden cursor-pointer group"
    >
      <div className={`bg-gradient-to-br ${card.bgGradient} p-6`}>
        <div className="flex justify-between items-start">
          <div className="flex-1">
            <p className="text-white/90 text-sm font-medium mb-2">
              {card.title}
            </p>
            <h3 className="text-2xl md:text-3xl font-bold text-white mb-2">
              {card.value}
            </h3>
            <div className="flex items-center gap-1">
              {card.growth >= 0 ? (
                <FaArrowUp className="text-white text-xs" />
              ) : (
                <FaArrowDown className="text-white text-xs" />
              )}
              <span className="text-white text-sm font-semibold">
                {Math.abs(card.growth)}%
              </span>
              <span className="text-white/80 text-xs">vs last month</span>
            </div>
          </div>
          <div
            className={`${card.iconBg} p-3 md:p-4 rounded-xl group-hover:scale-110 transition-transform`}
          >
            <span className={`${card.iconColor} text-2xl md:text-3xl`}>
              {card.icon}
            </span>
          </div>
        </div>
      </div>
      <div className="bg-gradient-to-r from-gray-50 to-white p-3">
        <button className="text-sm text-gray-600 hover:text-gray-900 font-medium flex items-center gap-2">
          View Details
          <span className="group-hover:translate-x-1 transition-transform">
            →
          </span>
        </button>
      </div>
    </div>
  );
};

export default StatsCard;
