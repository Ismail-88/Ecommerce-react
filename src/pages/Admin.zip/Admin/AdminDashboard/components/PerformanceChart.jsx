
import { RadialBar, RadialBarChart, ResponsiveContainer, Tooltip } from 'recharts';

const PerformanceChart = ({stats}) => {

    const performanceData = [
    { name: 'Sales', value: Math.min(((stats.totalOrders / 200) * 100), 100), fill: '#ef4444' },
    { name: 'Orders', value: Math.min(((stats.totalOrders / 150) * 100), 100), fill: '#10b981' },
    { name: 'Products', value: Math.min(((stats.totalProducts / 100) * 100), 100), fill: '#3b82f6' },
  ];

  return (
    <div className="bg-white rounded-2xl shadow-lg p-6">
              <div className="mb-6">
                <h2 className="text-xl font-bold text-gray-800">Performance</h2>
                <p className="text-sm text-gray-500">Monthly targets achieved</p>
              </div>
              <ResponsiveContainer width="100%" height={220}>
                <RadialBarChart
                  cx="50%"
                  cy="50%"
                  innerRadius="20%"
                  outerRadius="100%"
                  data={performanceData}
                  startAngle={90}
                  endAngle={-270}
                >
                  <RadialBar
                    minAngle={15}
                    label={{ position: 'insideStart', fill: '#fff', fontSize: 14 }}
                    background
                    clockWise
                    dataKey="value"
                  />
                  <Tooltip />
                </RadialBarChart>
              </ResponsiveContainer>
              <div className="mt-4 space-y-2">
                {performanceData.map((item, index) => (
                  <div key={index} className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div
                        className="w-3 h-3 rounded-full"
                        style={{ backgroundColor: item.fill }}
                      ></div>
                      <span className="text-sm text-gray-600">{item.name}</span>
                    </div>
                    <span className="text-sm font-semibold text-gray-800">
                      {Math.round(item.value)}%
                    </span>
                  </div>
                ))}
              </div>
            </div>
  )
}

export default PerformanceChart
