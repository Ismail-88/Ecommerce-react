
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from 'recharts';

export const WeeklyRevenueChart = () => {
  const revenueData = [
    { day: 'Mon', revenue: 1200, target: 1000 },
    { day: 'Tue', revenue: 1500, target: 1200 },
    { day: 'Wed', revenue: 1800, target: 1400 },
    { day: 'Thu', revenue: 1600, target: 1300 },
    { day: 'Fri', revenue: 2200, target: 1800 },
    { day: 'Sat', revenue: 2800, target: 2200 },
    { day: 'Sun', revenue: 2500, target: 2000 },
  ];

  return (
    <div className="bg-white rounded-2xl shadow-lg p-6">
      <div className="mb-6">
        <h2 className="text-xl font-bold text-gray-800">Weekly Revenue</h2>
        <p className="text-sm text-gray-500">Revenue vs Target comparison</p>
      </div>
      <ResponsiveContainer width="100%" height={300}>
        <BarChart data={revenueData}>
          <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
          <XAxis dataKey="day" stroke="#9ca3af" style={{ fontSize: '12px' }} />
          <YAxis stroke="#9ca3af" style={{ fontSize: '12px' }} />
          <Tooltip
            contentStyle={{
              backgroundColor: '#fff',
              border: 'none',
              borderRadius: '12px',
              boxShadow: '0 4px 6px rgba(0,0,0,0.1)',
            }}
          />
          <Legend />
          <Bar dataKey="revenue" fill="#10b981" radius={[8, 8, 0, 0]} />
          <Bar dataKey="target" fill="#e5e7eb" radius={[8, 8, 0, 0]} />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
};