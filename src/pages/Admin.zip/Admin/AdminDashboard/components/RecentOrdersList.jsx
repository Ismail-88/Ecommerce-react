import React from 'react'
import { FaEye } from 'react-icons/fa'
import { useNavigate } from 'react-router-dom'

const RecentOrdersList = ({recentOrders}) => {
    const navigate = useNavigate()
  return (
    <div className="bg-white rounded-2xl shadow-lg p-6">
          <div className="flex justify-between items-center mb-6">
            <div>
              <h2 className="text-xl font-bold text-gray-800">Recent Orders</h2>
              <p className="text-sm text-gray-500">Latest 5 orders</p>
            </div>
            <button
              onClick={() => navigate('/admin/orders')}
              className="text-sm text-red-500 hover:text-red-600 font-semibold flex items-center gap-1"
            >
              View All
              <FaEye />
            </button>
          </div>
          <div className="space-y-3">
            {recentOrders.length > 0 ? (
              recentOrders.map((order, index) => (
                <div
                  key={index}
                  onClick={() => navigate('/admin/orders')}
                  className="flex items-center justify-between p-3 bg-gray-50 rounded-xl hover:bg-gray-100 transition cursor-pointer"
                >
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-semibold text-gray-800 truncate">
                      {order.orderId || `#${order._id?.slice(-8)}`}
                    </p>
                    <p className="text-xs text-gray-500">
                      {new Date(order.orderDate || order.createdAt).toLocaleDateString()}
                    </p>
                  </div>
                  <div className="text-right ml-2">
                    <p className="text-sm font-bold text-red-500">
                      ${(order.pricing?.grandTotal || order.totalAmount || 0).toFixed(2)}
                    </p>
                    <span
                      className={`text-xs px-2 py-1 rounded-full whitespace-nowrap ${
                        order.status === 'pending'
                          ? 'bg-yellow-100 text-yellow-800'
                          : order.status === 'delivered'
                          ? 'bg-green-100 text-green-800'
                          : 'bg-blue-100 text-blue-800'
                      }`}
                    >
                      {order.status || 'pending'}
                    </span>
                  </div>
                </div>
              ))
            ) : (
              <div className="text-center py-12">
                <p className="text-gray-400 text-sm">No recent orders</p>
              </div>
            )}
          </div>
        </div>
  )
}

export default RecentOrdersList
