import React from 'react'

const AlertsBanner = ({ pendingOrders, lowStock }) => {
     if (pendingOrders === 0 && lowStock === 0) return null;
  return (
    <div className="bg-yellow-50 border-l-4 border-yellow-400 p-4 rounded-r-lg shadow">
            <div className="flex items-start gap-3">
              <div className="flex-shrink-0">
                <span className="text-2xl">⚠️</span>
              </div>
              <div>
                <h3 className="text-yellow-800 font-semibold mb-1">
                  Attention Required!
                </h3>
                <p className="text-yellow-700 text-sm">
                  {pendingOrders > 0 && (
                    <span className="mr-3">
                      📦 {pendingOrders} pending orders
                    </span>
                  )}
                  {lowStock > 0 && (
                    <span>
                      📉 {lowStock} products low in stock
                    </span>
                  )}
                </p>
              </div>
            </div>
          </div>
  )
}

export default AlertsBanner
