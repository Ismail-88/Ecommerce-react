
import {
  FaBoxOpen,
  FaShoppingCart,
  FaUsers,
  FaDollarSign,
  FaArrowUp,
  FaArrowDown,
  FaEye,
} from 'react-icons/fa';
import useDashboardData from './hooks/useDashboardData';
import DashboardHeader from './components/DashboardHeader';
import AlertsBanner from './components/AlertsBanner';
import StatsCard from './components/StatsCard';
import SaleOverviewChart from './components/SaleOverviewChart';
import { WeeklyRevenueChart } from './components/WeeklyRevenueChart';
import CategoryDistributionChart from './components/CategoryDistributionChart';
import PerformanceChart from './components/PerformanceChart';
import RecentOrdersList from './components/RecentOrdersList';
import TopProductsGrids from './components/TopProductsGrids';


const AdminDashboard = () => {
  
  const { stats,allOrders,recentOrders,topProducts,loading,categoryData,salesData} = useDashboardData()
 
  // Stats cards configuration
  const statsCards = [
    {
      title: 'Total Revenue',
      value: `$${stats.totalRevenue.toFixed(2)}`,
      growth: stats.revenueGrowth,
      icon: <FaDollarSign />,
      bgGradient: 'from-green-500 to-emerald-600',
      iconBg: 'bg-green-100',
      iconColor: 'text-green-600',
      link: '/admin/orders',
    },
    {
      title: 'Total Orders',
      value: stats.totalOrders,
      growth: stats.ordersGrowth,
      icon: <FaShoppingCart />,
      bgGradient: 'from-blue-500 to-cyan-600',
      iconBg: 'bg-blue-100',
      iconColor: 'text-blue-600',
      link: '/admin/orders',
    },
    {
      title: 'Total Products',
      value: stats.totalProducts,
      growth: stats.productsGrowth,
      icon: <FaBoxOpen />,
      bgGradient: 'from-purple-500 to-pink-600',
      iconBg: 'bg-purple-100',
      iconColor: 'text-purple-600',
      link: '/admin/products',
    },
    {
      title: 'Total Customers',
      value: stats.totalCustomers,
      growth: stats.customersGrowth,
      icon: <FaUsers />,
      bgGradient: 'from-orange-500 to-red-600',
      iconBg: 'bg-orange-100',
      iconColor: 'text-orange-600',
      link: '/admin/orders',
    },
  ];

  if (loading) {
    return (
      <div className="flex items-center justify-center h-screen bg-gray-50">
        <div className="text-center">
          <div className="animate-spin rounded-full h-16 w-16 border-b-4 border-red-500 mx-auto mb-4"></div>
          <p className="text-gray-600 font-semibold text-lg">Loading Dashboard...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 md:p-6 space-y-6 bg-gray-50 min-h-screen">
      {/* Welcome Header */}
      <div className="space-y-4">
       <DashboardHeader/>
        {/* Alerts */}
      <AlertsBanner
      
      pendingOrders={stats?.pendingOrders || 3}
      lowStock={stats?.lowStock || 2}
      />
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6">
        {statsCards.map((card, index)=>{
          <StatsCard key={index} card={card}/>
        })}
      </div>

      {/* Charts Row 1 */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Sales Overview */}
        <SaleOverviewChart salesData={salesData} />
        {/* Revenue vs Target */}
        <WeeklyRevenueChart />

      </div>

      {/* Charts Row 2 */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Category Distribution */}
        <CategoryDistributionChart categoryData={categoryData}/>
        {/* Performance Metrics */}
        <PerformanceChart stats={stats}/>
        {/* Recent Orders */}
        <RecentOrdersList recentOrders={recentOrders}/>
        
      </div>

      {/* Top Products */}
       <TopProductsGrids topProducts={topProducts}/>
    </div>
  );
};

export default AdminDashboard;